import React from 'react';
import { Navbar, Nav, Container, Dropdown } from 'react-bootstrap';
import { FaHouse, FaUserGraduate, FaChalkboardUser, FaBook, FaStar, FaUser, FaRightFromBracket } from 'react-icons/fa6';
import './Navigation.css';

export default function Navigation({ currentPage, setCurrentPage, currentUser, onLogout }) {
  return (
    <Navbar bg="dark" expand="lg" sticky="top" className="navbar-custom">
      <Container>
        <Navbar.Brand
          onClick={() => setCurrentPage('dashboard')}
          style={{ cursor: 'pointer' }}
          className="brand-text"
        >
          <FaBook className="me-2" />
          Gestão Escolar
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            <Nav.Link
              onClick={() => setCurrentPage('dashboard')}
              active={currentPage === 'dashboard'}
              className="nav-item-custom"
            >
              <FaHouse className="me-1" />
              Dashboard
            </Nav.Link>
            <Nav.Link
              onClick={() => setCurrentPage('alunos')}
              active={currentPage === 'alunos'}
              className="nav-item-custom"
            >
              <FaUserGraduate className="me-1" />
              Alunos
            </Nav.Link>
            <Nav.Link
              onClick={() => setCurrentPage('turmas')}
              active={currentPage === 'turmas'}
              className="nav-item-custom"
            >
              <FaChalkboardUser className="me-1" />
              Turmas
            </Nav.Link>
            <Nav.Link
              onClick={() => setCurrentPage('docentes')}
              active={currentPage === 'docentes'}
              className="nav-item-custom"
            >
              <FaBook className="me-1" />
              Docentes
            </Nav.Link>
            <Nav.Link
              onClick={() => setCurrentPage('avaliacoes')}
              active={currentPage === 'avaliacoes'}
              className="nav-item-custom"
            >
              <FaStar className="me-1" />
              Avaliações
            </Nav.Link>

            {/* Dropdown do Usuário */}
            {currentUser && (
              <Dropdown className="ms-3 user-dropdown">
                <Dropdown.Toggle variant="light" id="user-dropdown" className="user-toggle">
                  <FaUser className="me-1" />
                  {currentUser.name}
                </Dropdown.Toggle>

                <Dropdown.Menu align="end" className="user-menu">
                  <Dropdown.Header>
                    <div className="user-info">
                      <p className="user-name">{currentUser.name}</p>
                      <p className="user-email">{currentUser.email}</p>
                      <p className="user-role">{currentUser.role}</p>
                    </div>
                  </Dropdown.Header>
                  <Dropdown.Divider />
                  <Dropdown.Item onClick={onLogout} className="logout-item">
                    <FaRightFromBracket className="me-2" />
                    Sair
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
