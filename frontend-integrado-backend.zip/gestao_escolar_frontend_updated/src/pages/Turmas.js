import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Table, Modal, Form, Alert } from 'react-bootstrap';
import { FaPlus, FaPen, FaTrash, FaMagnifyingGlass, FaChalkboardUser } from 'react-icons/fa6';
import './CRUD.css';

export default function Turmas() {
  // Docentes e períodos pré-cadastrados
  const docentesPrecadastrados = [
    'Prof. João Silva',
    'Prof. Maria Santos',
    'Prof. Pedro Oliveira'
  ];

  const periodosPrecadastrados = ['Matutino', 'Vespertino', 'Noturno'];

  const [turmas, setTurmas] = useState([
    { id: 1, codigo: '10-A', descricao: 'Turma 10º Ano A', docente: 'Prof. João Silva', alunosCount: 25, periodo: 'Matutino', status: 'Ativa' },
    { id: 2, codigo: '10-B', descricao: 'Turma 10º Ano B', docente: 'Prof. Maria Santos', alunosCount: 23, periodo: 'Vespertino', status: 'Ativa' },
    { id: 3, codigo: '11-A', descricao: 'Turma 11º Ano A', docente: 'Prof. Pedro Oliveira', alunosCount: 22, periodo: 'Matutino', status: 'Ativa' },
  ]);

  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [message, setMessage] = useState(null);
  const [formData, setFormData] = useState({
    codigo: '',
    descricao: '',
    docente: '',
    alunosCount: '',
    periodo: 'Matutino',
    status: 'Ativa'
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    if (!formData.codigo || !formData.descricao || !formData.docente || !formData.alunosCount) {
      setMessage({ type: 'danger', text: 'Por favor, preencha todos os campos obrigatórios' });
      return;
    }

    if (editingId) {
      setTurmas(turmas.map(t => t.id === editingId ? { ...formData, id: editingId, alunosCount: parseInt(formData.alunosCount) } : t));
      setMessage({ type: 'success', text: 'Turma atualizada com sucesso!' });
    } else {
      const newTurma = { ...formData, id: Math.max(...turmas.map(t => t.id), 0) + 1, alunosCount: parseInt(formData.alunosCount) };
      setTurmas([...turmas, newTurma]);
      setMessage({ type: 'success', text: 'Turma adicionada com sucesso!' });
    }

    resetForm();
    setShowModal(false);
    setTimeout(() => setMessage(null), 3000);
  };

  const handleEdit = (turma) => {
    setFormData({ ...turma, alunosCount: turma.alunosCount.toString() });
    setEditingId(turma.id);
    setShowModal(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Deseja realmente deletar esta turma?')) {
      setTurmas(turmas.filter(t => t.id !== id));
      setMessage({ type: 'success', text: 'Turma deletada com sucesso!' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const handleShowModal = () => {
    resetForm();
    setEditingId(null);
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      codigo: '',
      descricao: '',
      docente: '',
      alunosCount: '',
      periodo: 'Matutino',
      status: 'Ativa'
    });
  };

  const filteredTurmas = turmas.filter(t =>
    t.codigo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.docente.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Container fluid>
      <div className="page-header">
        <h1><FaChalkboardUser className="me-2" />Gestão de Turmas</h1>
        <p>Organize e gerencie as turmas da escola</p>
      </div>

      {message && (
        <Alert variant={message.type} dismissible onClose={() => setMessage(null)}>
          {message.text}
        </Alert>
      )}

      <Row className="mb-4">
        <Col md={6}>
          <div className="search-box">
            <FaMagnifyingGlass className="search-icon" />
            <input
              type="text"
              placeholder="Buscar por código, descrição ou docente..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
          </div>
        </Col>
        <Col md={6} className="text-end">
          <Button variant="primary" onClick={handleShowModal} className="btn-add">
            <FaPlus className="me-2" />
            Adicionar Turma
          </Button>
        </Col>
      </Row>

      <Card className="data-card">
        <Card.Body>
          {filteredTurmas.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">📚</div>
              <p className="empty-state-title">Nenhuma turma encontrada</p>
              <p>Comece criando uma nova turma</p>
            </div>
          ) : (
            <div className="table-responsive">
              <Table hover className="mb-0">
                <thead>
                  <tr>
                    <th>Código</th>
                    <th>Descrição</th>
                    <th>Docente</th>
                    <th>Alunos</th>
                    <th>Período</th>
                    <th>Status</th>
                    <th>Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTurmas.map(turma => (
                    <tr key={turma.id}>
                      <td><strong>{turma.codigo}</strong></td>
                      <td>{turma.descricao}</td>
                      <td>{turma.docente}</td>
                      <td>{turma.alunosCount}</td>
                      <td>{turma.periodo}</td>
                      <td>
                        <span className={`badge badge-${turma.status === 'Ativa' ? 'success' : 'danger'}`}>
                          {turma.status}
                        </span>
                      </td>
                      <td>
                        <div className="action-buttons">
                          <Button
                            size="sm"
                            variant="outline-primary"
                            onClick={() => handleEdit(turma)}
                            title="Editar"
                          >
                            <FaPen />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline-danger"
                            onClick={() => handleDelete(turma.id)}
                            title="Deletar"
                          >
                            <FaTrash />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>
          )}
        </Card.Body>
      </Card>

      <Modal show={showModal} onHide={() => setShowModal(false)} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>{editingId ? 'Editar Turma' : 'Adicionar Nova Turma'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Código da Turma *</Form.Label>
                  <Form.Control
                    type="text"
                    name="codigo"
                    value={formData.codigo}
                    onChange={handleInputChange}
                    placeholder="Ex: 10-A"
                  />
                </Form.Group>
              </Col>

              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Descrição *</Form.Label>
                  <Form.Control
                    type="text"
                    name="descricao"
                    value={formData.descricao}
                    onChange={handleInputChange}
                    placeholder="Ex: Turma 10º Ano A"
                  />
                </Form.Group>
              </Col>
            </Row>

            <Form.Group className="mb-3">
              <Form.Label>Docente *</Form.Label>
              <Form.Select
                name="docente"
                value={formData.docente}
                onChange={handleInputChange}
              >
                <option value="">Selecione um docente</option>
                {docentesPrecadastrados.map((docente, idx) => (
                  <option key={idx} value={docente}>
                    {docente}
                  </option>
                ))}
              </Form.Select>
            </Form.Group>

            <Row>
              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>Número de Alunos *</Form.Label>
                  <Form.Control
                    type="number"
                    name="alunosCount"
                    value={formData.alunosCount}
                    onChange={handleInputChange}
                    placeholder="0"
                  />
                </Form.Group>
              </Col>

              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>Período</Form.Label>
                  <Form.Select
                    name="periodo"
                    value={formData.periodo}
                    onChange={handleInputChange}
                  >
                    {periodosPrecadastrados.map((periodo, idx) => (
                      <option key={idx} value={periodo}>
                        {periodo}
                      </option>
                    ))}
                  </Form.Select>
                </Form.Group>
              </Col>

              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>Status</Form.Label>
                  <Form.Select
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                  >
                    <option value="Ativa">Ativa</option>
                    <option value="Inativa">Inativa</option>
                  </Form.Select>
                </Form.Group>
              </Col>
            </Row>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancelar
          </Button>
          <Button variant="primary" onClick={handleSave}>
            {editingId ? 'Atualizar' : 'Adicionar'}
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
}
