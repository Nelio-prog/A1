import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';
import { FaUsers, FaGraduationCap, FaChalkboardUser, FaStar } from 'react-icons/fa6';
import './Dashboard.css';

export default function Dashboard() {
  const stats = [
    { icon: FaGraduationCap, label: 'Total de Alunos', value: '245', color: '#3498db' },
    { icon: FaChalkboardUser, label: 'Turmas Ativas', value: '12', color: '#27ae60' },
    { icon: FaUsers, label: 'Docentes', value: '18', color: '#e74c3c' },
    { icon: FaStar, label: 'Avaliações Pendentes', value: '5', color: '#f39c12' },
  ];

  return (
    <Container fluid>
      <div className="dashboard-header">
        <h1>Dashboard</h1>
        <p>Bem-vindo ao Sistema de Gestão Escolar</p>
      </div>

      <Row className="mb-5">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <Col key={idx} md={6} lg={3} className="mb-4">
              <Card className="stat-card" style={{ borderTop: `4px solid ${stat.color}` }}>
                <Card.Body>
                  <div className="d-flex justify-content-between align-items-start">
                    <div>
                      <p className="stat-label">{stat.label}</p>
                      <p className="stat-value">{stat.value}</p>
                    </div>
                    <Icon className="stat-icon" style={{ color: stat.color, opacity: 0.2 }} />
                  </div>
                </Card.Body>
              </Card>
            </Col>
          );
        })}
      </Row>

      <Row className="mb-5">
        <Col lg={6}>
          <Card className="dashboard-card">
            <Card.Header>Atividades Recentes</Card.Header>
            <Card.Body>
              <div className="activity-list">
                <div className="activity-item">
                  <div className="activity-dot"></div>
                  <div className="activity-content">
                    <p className="activity-title">Novo aluno cadastrado</p>
                    <p className="activity-time">há 2 horas</p>
                  </div>
                </div>
                <div className="activity-item">
                  <div className="activity-dot"></div>
                  <div className="activity-content">
                    <p className="activity-title">Turma 10-A criada</p>
                    <p className="activity-time">há 5 horas</p>
                  </div>
                </div>
                <div className="activity-item">
                  <div className="activity-dot"></div>
                  <div className="activity-content">
                    <p className="activity-title">Avaliação finalizada</p>
                    <p className="activity-time">há 1 dia</p>
                  </div>
                </div>
              </div>
            </Card.Body>
          </Card>
        </Col>

        <Col lg={6}>
          <Card className="dashboard-card">
            <Card.Header>Próximas Ações</Card.Header>
            <Card.Body>
              <div className="action-list">
                <div className="action-item">
                  <input type="checkbox" id="action1" className="action-checkbox" />
                  <label htmlFor="action1">Revisar avaliações pendentes</label>
                </div>
                <div className="action-item">
                  <input type="checkbox" id="action2" className="action-checkbox" />
                  <label htmlFor="action2">Atualizar notas do trimestre</label>
                </div>
                <div className="action-item">
                  <input type="checkbox" id="action3" className="action-checkbox" />
                  <label htmlFor="action3">Confirmar presença de docentes</label>
                </div>
                <div className="action-item">
                  <input type="checkbox" id="action4" className="action-checkbox" />
                  <label htmlFor="action4">Agendar reunião de pais</label>
                </div>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row>
        <Col>
          <Card className="dashboard-card">
            <Card.Header>Dicas de Usabilidade</Card.Header>
            <Card.Body>
              <ul className="tips-list">
                <li><strong>Alunos:</strong> Cadastre e gerencie dados dos alunos, acompanhando seu histórico acadêmico.</li>
                <li><strong>Turmas:</strong> Organize turmas, atribua docentes e gerencie matrículas.</li>
                <li><strong>Docentes:</strong> Registre informações dos professores e sua alocação em turmas.</li>
                <li><strong>Avaliações:</strong> Registre notas e avaliações de desempenho dos alunos.</li>
              </ul>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}
