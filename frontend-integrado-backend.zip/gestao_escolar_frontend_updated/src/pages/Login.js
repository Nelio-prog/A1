import React, {useState} from 'react';
import { apiLogin } from '../services/api';

export default function Login({onLogin}){
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [error,setError] = useState("");

  async function handleLogin(e){
    e.preventDefault();
    const res = await apiLogin(email,password);
    if(res.token){
      onLogin(res.token, res.user);
    } else {
      setError(res.message);
    }
  }

  return (
    <div style={{maxWidth:300, margin:"40px auto"}}>
      <h2>Login</h2>
      {error && <div style={{color:"red"}}>{error}</div>}
      <form onSubmit={handleLogin}>
        <input placeholder="Email" value={email}
          onChange={e=>setEmail(e.target.value)} /><br/><br/>
        <input placeholder="Password" type="password" value={password}
          onChange={e=>setPassword(e.target.value)} /><br/><br/>
        <button>Entrar</button>
      </form>
    </div>
  );
}
