import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Table, Modal, Form, Alert } from 'react-bootstrap';
import { FaPlus, FaPen, FaTrash, FaMagnifyingGlass, FaStar } from 'react-icons/fa6';
import './CRUD.css';

export default function Avaliacoes() {
  // Dados pré-cadastrados
  const alunosPrecadastrados = [
    { id: 1, nome: 'João Silva', turma: '10-A' },
    { id: 2, nome: 'Maria Santos', turma: '10-B' },
    { id: 3, nome: 'Pedro Oliveira', turma: '10-A' },
  ];

  const turmasPrecadastradas = ['10-A', '10-B', '11-A', '11-B', '12-A'];

  const disciplinasPrecadastradas = [
    'Matemática', 'Português', 'Inglês', 'Física', 'Química', 'Biologia', 'História', 'Geografia'
  ];

  const [avaliacoes, setAvaliacoes] = useState([
    { id: 1, aluno: 'João Silva', turma: '10-A', disciplina: 'Matemática', nota: 8.5, data: '2024-11-15', status: 'Concluída' },
    { id: 2, aluno: 'Maria Santos', turma: '10-B', disciplina: 'Português', nota: 9.0, data: '2024-11-14', status: 'Concluída' },
    { id: 3, aluno: 'Pedro Oliveira', turma: '10-A', disciplina: 'Física', nota: 7.5, data: '2024-11-13', status: 'Concluída' },
  ]);

  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [message, setMessage] = useState(null);
  const [formData, setFormData] = useState({
    aluno: '',
    turma: '',
    disciplina: '',
    nota: '',
    data: '',
    status: 'Concluída'
  });

  const getNotaColor = (nota) => {
    if (nota >= 8) return '#27ae60';
    if (nota >= 6) return '#f39c12';
    return '#e74c3c';
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    // Se o aluno foi alterado, auto-preencher a turma
    if (name === 'aluno' && value) {
      const alunoSelecionado = alunosPrecadastrados.find(a => a.nome === value);
      setFormData(prev => ({
        ...prev,
        [name]: value,
        turma: alunoSelecionado ? alunoSelecionado.turma : ''
      }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSave = () => {
    if (!formData.aluno || !formData.turma || !formData.disciplina || !formData.nota || !formData.data) {
      setMessage({ type: 'danger', text: 'Por favor, preencha todos os campos obrigatórios' });
      return;
    }

    const nota = parseFloat(formData.nota);
    if (nota < 0 || nota > 20) {
      setMessage({ type: 'danger', text: 'A nota deve estar entre 0 e 20' });
      return;
    }

    if (editingId) {
      setAvaliacoes(avaliacoes.map(a => a.id === editingId ? { ...formData, id: editingId, nota } : a));
      setMessage({ type: 'success', text: 'Avaliação atualizada com sucesso!' });
    } else {
      const newAvaliacao = { ...formData, id: Math.max(...avaliacoes.map(a => a.id), 0) + 1, nota };
      setAvaliacoes([...avaliacoes, newAvaliacao]);
      setMessage({ type: 'success', text: 'Avaliação adicionada com sucesso!' });
    }

    resetForm();
    setShowModal(false);
    setTimeout(() => setMessage(null), 3000);
  };

  const handleEdit = (avaliacao) => {
    setFormData({ ...avaliacao, nota: avaliacao.nota.toString() });
    setEditingId(avaliacao.id);
    setShowModal(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Deseja realmente deletar esta avaliação?')) {
      setAvaliacoes(avaliacoes.filter(a => a.id !== id));
      setMessage({ type: 'success', text: 'Avaliação deletada com sucesso!' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const handleShowModal = () => {
    resetForm();
    setEditingId(null);
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      aluno: '',
      turma: '',
      disciplina: '',
      nota: '',
      data: '',
      status: 'Concluída'
    });
  };

  const filteredAvaliacoes = avaliacoes.filter(a =>
    a.aluno.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.disciplina.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.turma.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const media = avaliacoes.length > 0
    ? (avaliacoes.reduce((sum, a) => sum + a.nota, 0) / avaliacoes.length).toFixed(2)
    : 0;

  return (
    <Container fluid>
      <div className="page-header">
        <h1><FaStar className="me-2" />Gestão de Avaliações</h1>
        <p>Registre e acompanhe as avaliações dos alunos</p>
      </div>

      {message && (
        <Alert variant={message.type} dismissible onClose={() => setMessage(null)}>
          {message.text}
        </Alert>
      )}

      <Row className="mb-4">
        <Col md={6} lg={3}>
          <Card className="stat-card">
            <Card.Body>
              <p className="stat-label">Total de Avaliações</p>
              <p className="stat-value">{avaliacoes.length}</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={6} lg={3}>
          <Card className="stat-card">
            <Card.Body>
              <p className="stat-label">Média Geral</p>
              <p className="stat-value" style={{ color: getNotaColor(media) }}>{media}</p>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row className="mb-4">
        <Col md={6}>
          <div className="search-box">
            <FaMagnifyingGlass className="search-icon" />
            <input
              type="text"
              placeholder="Buscar por aluno, disciplina ou turma..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
          </div>
        </Col>
        <Col md={6} className="text-end">
          <Button variant="primary" onClick={handleShowModal} className="btn-add">
            <FaPlus className="me-2" />
            Adicionar Avaliação
          </Button>
        </Col>
      </Row>

      <Card className="data-card">
        <Card.Body>
          {filteredAvaliacoes.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">📊</div>
              <p className="empty-state-title">Nenhuma avaliação encontrada</p>
              <p>Comece registrando uma nova avaliação</p>
            </div>
          ) : (
            <div className="table-responsive">
              <Table hover className="mb-0">
                <thead>
                  <tr>
                    <th>Aluno</th>
                    <th>Turma</th>
                    <th>Disciplina</th>
                    <th>Nota</th>
                    <th>Data</th>
                    <th>Status</th>
                    <th>Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAvaliacoes.map(avaliacao => (
                    <tr key={avaliacao.id}>
                      <td><strong>{avaliacao.aluno}</strong></td>
                      <td>{avaliacao.turma}</td>
                      <td>{avaliacao.disciplina}</td>
                      <td>
                        <div className="nota-badge" style={{ backgroundColor: getNotaColor(avaliacao.nota) }}>
                          {avaliacao.nota}
                        </div>
                      </td>
                      <td>{new Date(avaliacao.data).toLocaleDateString('pt-BR')}</td>
                      <td>
                        <span className={`badge badge-${avaliacao.status === 'Concluída' ? 'success' : 'warning'}`}>
                          {avaliacao.status}
                        </span>
                      </td>
                      <td>
                        <div className="action-buttons">
                          <Button
                            size="sm"
                            variant="outline-primary"
                            onClick={() => handleEdit(avaliacao)}
                            title="Editar"
                          >
                            <FaPen />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline-danger"
                            onClick={() => handleDelete(avaliacao.id)}
                            title="Deletar"
                          >
                            <FaTrash />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>
          )}
        </Card.Body>
      </Card>

      <Modal show={showModal} onHide={() => setShowModal(false)} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>{editingId ? 'Editar Avaliação' : 'Adicionar Nova Avaliação'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Aluno *</Form.Label>
                  <Form.Select
                    name="aluno"
                    value={formData.aluno}
                    onChange={handleInputChange}
                  >
                    <option value="">Selecione um aluno</option>
                    {alunosPrecadastrados.map(aluno => (
                      <option key={aluno.id} value={aluno.nome}>
                        {aluno.nome}
                      </option>
                    ))}
                  </Form.Select>
                </Form.Group>
              </Col>

              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Turma * (Auto-preenchida)</Form.Label>
                  <Form.Control
                    type="text"
                    name="turma"
                    value={formData.turma}
                    disabled
                    placeholder="Será preenchida automaticamente"
                  />
                </Form.Group>
              </Col>
            </Row>

            <Form.Group className="mb-3">
              <Form.Label>Disciplina *</Form.Label>
              <Form.Select
                name="disciplina"
                value={formData.disciplina}
                onChange={handleInputChange}
              >
                <option value="">Selecione uma disciplina</option>
                {disciplinasPrecadastradas.map((disciplina, idx) => (
                  <option key={idx} value={disciplina}>
                    {disciplina}
                  </option>
                ))}
              </Form.Select>
            </Form.Group>

            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Nota (0-20) *</Form.Label>
                  <Form.Control
                    type="number"
                    name="nota"
                    step="0.5"
                    min="0"
                    max="20"
                    value={formData.nota}
                    onChange={handleInputChange}
                    placeholder="0"
                  />
                </Form.Group>
              </Col>

              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Data da Avaliação *</Form.Label>
                  <Form.Control
                    type="date"
                    name="data"
                    value={formData.data}
                    onChange={handleInputChange}
                  />
                </Form.Group>
              </Col>
            </Row>

            <Form.Group className="mb-3">
              <Form.Label>Status</Form.Label>
              <Form.Select
                name="status"
                value={formData.status}
                onChange={handleInputChange}
              >
                <option value="Concluída">Concluída</option>
                <option value="Pendente">Pendente</option>
              </Form.Select>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancelar
          </Button>
          <Button variant="primary" onClick={handleSave}>
            {editingId ? 'Atualizar' : 'Adicionar'}
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
}
