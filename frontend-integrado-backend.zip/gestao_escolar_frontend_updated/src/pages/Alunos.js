import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Table, Modal, Form, Alert } from 'react-bootstrap';
import { FaPlus, FaPen, FaTrash, FaMagnifyingGlass, FaUserGraduate } from 'react-icons/fa6';
import './CRUD.css';

export default function Alunos() {
  // Turmas pré-cadastradas
  const turmasPrecadastradas = ['10-A', '10-B', '11-A', '11-B', '12-A'];

  const [alunos, setAlunos] = useState([
    { id: 1, nome: 'João Silva', matricula: 'ALU001', email: 'joao@example.com', turma: '10-A', status: 'Ativo' },
    { id: 2, nome: 'Maria Santos', matricula: 'ALU002', email: 'maria@example.com', turma: '10-B', status: 'Ativo' },
    { id: 3, nome: 'Pedro Oliveira', matricula: 'ALU003', email: 'pedro@example.com', turma: '10-A', status: 'Ativo' },
  ]);

  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [message, setMessage] = useState(null);
  const [formData, setFormData] = useState({
    nome: '',
    matricula: '',
    email: '',
    turma: '',
    status: 'Ativo'
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    if (!formData.nome || !formData.matricula || !formData.email || !formData.turma) {
      setMessage({ type: 'danger', text: 'Por favor, preencha todos os campos obrigatórios' });
      return;
    }

    if (editingId) {
      setAlunos(alunos.map(a => a.id === editingId ? { ...formData, id: editingId } : a));
      setMessage({ type: 'success', text: 'Aluno atualizado com sucesso!' });
    } else {
      const newAluno = { ...formData, id: Math.max(...alunos.map(a => a.id), 0) + 1 };
      setAlunos([...alunos, newAluno]);
      setMessage({ type: 'success', text: 'Aluno adicionado com sucesso!' });
    }

    resetForm();
    setShowModal(false);
    setTimeout(() => setMessage(null), 3000);
  };

  const handleEdit = (aluno) => {
    setFormData(aluno);
    setEditingId(aluno.id);
    setShowModal(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Deseja realmente deletar este aluno?')) {
      setAlunos(alunos.filter(a => a.id !== id));
      setMessage({ type: 'success', text: 'Aluno deletado com sucesso!' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const handleShowModal = () => {
    resetForm();
    setEditingId(null);
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      nome: '',
      matricula: '',
      email: '',
      turma: '',
      status: 'Ativo'
    });
  };

  const filteredAlunos = alunos.filter(a =>
    a.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.matricula.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Container fluid>
      <div className="page-header">
        <h1><FaUserGraduate className="me-2" />Gestão de Alunos</h1>
        <p>Cadastre e gerencie informações dos alunos</p>
      </div>

      {message && (
        <Alert variant={message.type} dismissible onClose={() => setMessage(null)}>
          {message.text}
        </Alert>
      )}

      <Row className="mb-4">
        <Col md={6}>
          <div className="search-box">
            <FaMagnifyingGlass className="search-icon" />
            <input
              type="text"
              placeholder="Buscar por nome, matrícula ou email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
          </div>
        </Col>
        <Col md={6} className="text-end">
          <Button variant="primary" onClick={handleShowModal} className="btn-add">
            <FaPlus className="me-2" />
            Adicionar Aluno
          </Button>
        </Col>
      </Row>

      <Card className="data-card">
        <Card.Body>
          {filteredAlunos.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">👥</div>
              <p className="empty-state-title">Nenhum aluno encontrado</p>
              <p>Comece adicionando um novo aluno ao sistema</p>
            </div>
          ) : (
            <div className="table-responsive">
              <Table hover className="mb-0">
                <thead>
                  <tr>
                    <th>Nome</th>
                    <th>Matrícula</th>
                    <th>Email</th>
                    <th>Turma</th>
                    <th>Status</th>
                    <th>Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAlunos.map(aluno => (
                    <tr key={aluno.id}>
                      <td><strong>{aluno.nome}</strong></td>
                      <td>{aluno.matricula}</td>
                      <td>{aluno.email}</td>
                      <td>{aluno.turma}</td>
                      <td>
                        <span className={`badge badge-${aluno.status === 'Ativo' ? 'success' : 'danger'}`}>
                          {aluno.status}
                        </span>
                      </td>
                      <td>
                        <div className="action-buttons">
                          <Button
                            size="sm"
                            variant="outline-primary"
                            onClick={() => handleEdit(aluno)}
                            title="Editar"
                          >
                            <FaPen />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline-danger"
                            onClick={() => handleDelete(aluno.id)}
                            title="Deletar"
                          >
                            <FaTrash />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>
          )}
        </Card.Body>
      </Card>

      <Modal show={showModal} onHide={() => setShowModal(false)} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>{editingId ? 'Editar Aluno' : 'Adicionar Novo Aluno'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Nome Completo *</Form.Label>
              <Form.Control
                type="text"
                name="nome"
                value={formData.nome}
                onChange={handleInputChange}
                placeholder="Digite o nome completo"
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Matrícula *</Form.Label>
              <Form.Control
                type="text"
                name="matricula"
                value={formData.matricula}
                onChange={handleInputChange}
                placeholder="Digite a matrícula"
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Email *</Form.Label>
              <Form.Control
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="Digite o email"
              />
            </Form.Group>

            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Turma *</Form.Label>
                  <Form.Select
                    name="turma"
                    value={formData.turma}
                    onChange={handleInputChange}
                  >
                    <option value="">Selecione uma turma</option>
                    {turmasPrecadastradas.map((turma, idx) => (
                      <option key={idx} value={turma}>
                        {turma}
                      </option>
                    ))}
                  </Form.Select>
                </Form.Group>
              </Col>

              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Status</Form.Label>
                  <Form.Select
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                  >
                    <option value="Ativo">Ativo</option>
                    <option value="Inativo">Inativo</option>
                  </Form.Select>
                </Form.Group>
              </Col>
            </Row>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancelar
          </Button>
          <Button variant="primary" onClick={handleSave}>
            {editingId ? 'Atualizar' : 'Adicionar'}
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
}
