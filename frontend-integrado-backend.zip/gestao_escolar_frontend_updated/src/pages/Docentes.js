import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Table, Modal, Form, Alert } from 'react-bootstrap';
import { FaPlus, FaPen, FaTrash, FaMagnifyingGlass, FaBook } from 'react-icons/fa6';
import './CRUD.css';

export default function Docentes() {
  const [docentes, setDocentes] = useState([
    { id: 1, nome: 'Prof. João Silva', email: 'joao.silva@example.com', especialidade: 'Matemática', telefone: '9XXXXXXXX', status: 'Ativo' },
    { id: 2, nome: 'Prof. Maria Santos', email: 'maria.santos@example.com', especialidade: 'Português', telefone: '9XXXXXXXX', status: 'Ativo' },
    { id: 3, nome: 'Prof. Pedro Oliveira', email: 'pedro.oliveira@example.com', especialidade: 'Física', telefone: '9XXXXXXXX', status: 'Ativo' },
  ]);

  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [message, setMessage] = useState(null);
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    especialidade: '',
    telefone: '',
    status: 'Ativo'
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    if (!formData.nome || !formData.email || !formData.especialidade || !formData.telefone) {
      setMessage({ type: 'danger', text: 'Por favor, preencha todos os campos obrigatórios' });
      return;
    }

    if (editingId) {
      setDocentes(docentes.map(d => d.id === editingId ? { ...formData, id: editingId } : d));
      setMessage({ type: 'success', text: 'Docente atualizado com sucesso!' });
    } else {
      const newDocente = { ...formData, id: Math.max(...docentes.map(d => d.id), 0) + 1 };
      setDocentes([...docentes, newDocente]);
      setMessage({ type: 'success', text: 'Docente adicionado com sucesso!' });
    }

    resetForm();
    setShowModal(false);
    setTimeout(() => setMessage(null), 3000);
  };

  const handleEdit = (docente) => {
    setFormData(docente);
    setEditingId(docente.id);
    setShowModal(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Deseja realmente deletar este docente?')) {
      setDocentes(docentes.filter(d => d.id !== id));
      setMessage({ type: 'success', text: 'Docente deletado com sucesso!' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const handleShowModal = () => {
    resetForm();
    setEditingId(null);
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      nome: '',
      email: '',
      especialidade: '',
      telefone: '',
      status: 'Ativo'
    });
  };

  const filteredDocentes = docentes.filter(d =>
    d.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.especialidade.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Container fluid>
      <div className="page-header">
        <h1><FaBook className="me-2" />Gestão de Docentes</h1>
        <p>Cadastre e gerencie informações dos professores</p>
      </div>

      {message && (
        <Alert variant={message.type} dismissible onClose={() => setMessage(null)}>
          {message.text}
        </Alert>
      )}

      <Row className="mb-4">
        <Col md={6}>
          <div className="search-box">
            <FaMagnifyingGlass className="search-icon" />
            <input
              type="text"
              placeholder="Buscar por nome, email ou especialidade..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
          </div>
        </Col>
        <Col md={6} className="text-end">
          <Button variant="primary" onClick={handleShowModal} className="btn-add">
            <FaPlus className="me-2" />
            Adicionar Docente
          </Button>
        </Col>
      </Row>

      <Card className="data-card">
        <Card.Body>
          {filteredDocentes.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">👨‍🏫</div>
              <p className="empty-state-title">Nenhum docente encontrado</p>
              <p>Comece adicionando um novo docente ao sistema</p>
            </div>
          ) : (
            <div className="table-responsive">
              <Table hover className="mb-0">
                <thead>
                  <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Especialidade</th>
                    <th>Telefone</th>
                    <th>Status</th>
                    <th>Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredDocentes.map(docente => (
                    <tr key={docente.id}>
                      <td><strong>{docente.nome}</strong></td>
                      <td>{docente.email}</td>
                      <td>{docente.especialidade}</td>
                      <td>{docente.telefone}</td>
                      <td>
                        <span className={`badge badge-${docente.status === 'Ativo' ? 'success' : 'danger'}`}>
                          {docente.status}
                        </span>
                      </td>
                      <td>
                        <div className="action-buttons">
                          <Button
                            size="sm"
                            variant="outline-primary"
                            onClick={() => handleEdit(docente)}
                            title="Editar"
                          >
                            <FaPen />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline-danger"
                            onClick={() => handleDelete(docente.id)}
                            title="Deletar"
                          >
                            <FaTrash />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>
          )}
        </Card.Body>
      </Card>

      <Modal show={showModal} onHide={() => setShowModal(false)} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>{editingId ? 'Editar Docente' : 'Adicionar Novo Docente'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Nome Completo *</Form.Label>
              <Form.Control
                type="text"
                name="nome"
                value={formData.nome}
                onChange={handleInputChange}
                placeholder="Digite o nome completo"
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Email *</Form.Label>
              <Form.Control
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="Digite o email"
              />
            </Form.Group>

            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Especialidade *</Form.Label>
                  <Form.Select
                    name="especialidade"
                    value={formData.especialidade}
                    onChange={handleInputChange}
                  >
                    <option value="">Selecione uma especialidade</option>
                    <option value="Matemática">Matemática</option>
                    <option value="Português">Português</option>
                    <option value="Inglês">Inglês</option>
                    <option value="Física">Física</option>
                    <option value="Química">Química</option>
                    <option value="Biologia">Biologia</option>
                    <option value="História">História</option>
                    <option value="Geografia">Geografia</option>
                    <option value="Educação Física">Educação Física</option>
                  </Form.Select>
                </Form.Group>
              </Col>

              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Telefone *</Form.Label>
                  <Form.Control
                    type="tel"
                    name="telefone"
                    value={formData.telefone}
                    onChange={handleInputChange}
                    placeholder="Digite o telefone"
                  />
                </Form.Group>
              </Col>
            </Row>

            <Form.Group className="mb-3">
              <Form.Label>Status</Form.Label>
              <Form.Select
                name="status"
                value={formData.status}
                onChange={handleInputChange}
              >
                <option value="Ativo">Ativo</option>
                <option value="Inativo">Inativo</option>
              </Form.Select>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancelar
          </Button>
          <Button variant="primary" onClick={handleSave}>
            {editingId ? 'Atualizar' : 'Adicionar'}
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
}
