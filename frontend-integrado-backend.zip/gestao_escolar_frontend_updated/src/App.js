import React, {useState,useEffect} from 'react';
import Login from './pages/Login';
import { apiGetStudents } from './services/api';

function App(){
  const [token,setToken] = useState(null);
  const [students,setStudents] = useState([]);

  async function loadStudents(t){
    const list = await apiGetStudents(t);
    setStudents(list);
  }

  function handleLogin(t){
    setToken(t);
    loadStudents(t);
  }

  if(!token) return <Login onLogin={handleLogin} />;

  return (
    <div style={{padding:20}}>
      <h2>Alunos</h2>
      <ul>
        {students.map(s=>(
          <li key={s._id}>{s.firstName} {s.lastName} - {s.registrationNumber}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
