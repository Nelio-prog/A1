const API_URL = "http://localhost:5000/api";

export async function apiLogin(email, password){
  const res = await fetch(`${API_URL}/auth/login`, {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({email,password})
  });
  return res.json();
}

export async function apiGetStudents(token){
  const res = await fetch(`${API_URL}/students`,{
    headers:{ Authorization:`Bearer ${token}` }
  });
  return res.json();
}

export async function apiCreateStudent(token, data){
  const res = await fetch(`${API_URL}/students`,{
    method:"POST",
    headers:{
      "Content-Type":"application/json",
      Authorization:`Bearer ${token}`
    },
    body: JSON.stringify(data)
  });
  return res.json();
}
